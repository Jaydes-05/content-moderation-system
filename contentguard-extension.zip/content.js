/**
 * ContentGuard — Content Script
 * Injected into every page. Detects platform, scrapes comments,
 * injects the floating panel, and handles per-comment interactions.
 */

(function () {
  'use strict';

  // Prevent double-injection
  if (window.__contentGuardInjected) return;
  window.__contentGuardInjected = true;

  // ── Constants ───────────────────────────────────────────────────────────────
  const PANEL_ID = 'contentguard-panel';
  const FAB_ID = 'contentguard-fab';
  const SUPPORTED_LANGS = [
    { code: 'es', name: 'Spanish' },
    { code: 'fr', name: 'French' },
    { code: 'de', name: 'German' },
    { code: 'hi', name: 'Hindi' },
    { code: 'zh', name: 'Chinese' },
    { code: 'ar', name: 'Arabic' },
    { code: 'pt', name: 'Portuguese' },
    { code: 'ja', name: 'Japanese' },
    { code: 'ko', name: 'Korean' },
    { code: 'ru', name: 'Russian' },
    { code: 'it', name: 'Italian' },
    { code: 'nl', name: 'Dutch' },
  ];

  // ── Platform Detection ──────────────────────────────────────────────────────
  const PLATFORMS = {
    twitter: {
      name: 'Twitter / X',
      icon: '𝕏',
      detect: () => /twitter\.com|x\.com/.test(location.hostname),
      scrapeComments: scrapeTwitter,
      commentSelector: '[data-testid="tweet"]',
    },
    reddit: {
      name: 'Reddit',
      icon: '🤖',
      detect: () => /reddit\.com/.test(location.hostname),
      scrapeComments: scrapeReddit,
      commentSelector: '[data-testid="comment"], .Comment',
    },
    instagram: {
      name: 'Instagram',
      icon: '📸',
      detect: () => /instagram\.com/.test(location.hostname),
      scrapeComments: scrapeInstagram,
      commentSelector: '._a9zs, ._a9ym',
    },
    youtube: {
      name: 'YouTube',
      icon: '▶️',
      detect: () => /youtube\.com/.test(location.hostname),
      scrapeComments: scrapeYouTube,
      commentSelector: 'ytd-comment-renderer',
    },
    hackernews: {
      name: 'Hacker News',
      icon: '🔶',
      detect: () => /news\.ycombinator\.com/.test(location.hostname),
      scrapeComments: scrapeHackerNews,
      commentSelector: '.comment',
    },
    generic: {
      name: 'This Page',
      icon: '🌐',
      detect: () => true,
      scrapeComments: scrapeGeneric,
      commentSelector: '[class*="comment"], article p',
    },
  };

  // ── State ───────────────────────────────────────────────────────────────────
  let state = {
    isOpen: false,
    isAnalyzing: false,
    platform: null,
    results: null,
    backendOnline: false,
    activeTab: 'stats', // 'stats' | 'comments' | 'block'
    selectedLang: 'es',
    translating: {}, // commentId → {loading, translated}
  };

  // ── Init ────────────────────────────────────────────────────────────────────
  function init() {
    state.platform = detectPlatform();
    injectFAB();
    checkBackend();

    // Watch for navigation (SPA)
    const origPushState = history.pushState.bind(history);
    history.pushState = function (...args) {
      origPushState(...args);
      setTimeout(() => {
        state.results = null;
        if (state.isOpen) analyzeAndRender();
      }, 1500);
    };
    window.addEventListener('popstate', () => {
      state.results = null;
      if (state.isOpen) setTimeout(analyzeAndRender, 1500);
    });
  }

  // ── Platform Detection ──────────────────────────────────────────────────────
  function detectPlatform() {
    for (const [key, p] of Object.entries(PLATFORMS)) {
      if (key !== 'generic' && p.detect()) return p;
    }
    return PLATFORMS.generic;
  }

  // ── Backend Check ───────────────────────────────────────────────────────────
  async function checkBackend() {
    const res = await sendMessage({ type: 'CHECK_BACKEND' });
    state.backendOnline = res?.online || false;
    updateFABStatus();
  }

  // ── FAB (Floating Action Button) ────────────────────────────────────────────
  function injectFAB() {
    if (document.getElementById(FAB_ID)) return;

    const fab = document.createElement('div');
    fab.id = FAB_ID;
    fab.innerHTML = `
      <div class="cg-fab-inner">
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15l-4-4 1.41-1.41L11 14.17l7.59-7.59L20 8l-9 9z" fill="currentColor"/>
        </svg>
        <span class="cg-fab-label">ContentGuard</span>
        <span class="cg-fab-dot" id="cg-status-dot"></span>
      </div>
    `;
    fab.title = 'Open ContentGuard Panel';
    fab.addEventListener('click', togglePanel);
    document.body.appendChild(fab);
  }

  function updateFABStatus() {
    const dot = document.getElementById('cg-status-dot');
    if (dot) {
      dot.className = 'cg-fab-dot ' + (state.backendOnline ? 'online' : 'offline');
      dot.title = state.backendOnline ? 'Backend connected' : 'Backend offline — start uvicorn';
    }
  }

  // ── Panel ───────────────────────────────────────────────────────────────────
  function togglePanel() {
    if (state.isOpen) {
      closePanel();
    } else {
      openPanel();
    }
  }

  function openPanel() {
    state.isOpen = true;
    let panel = document.getElementById(PANEL_ID);
    if (!panel) {
      panel = createPanelElement();
      document.body.appendChild(panel);
      makeDraggable(panel);
    }
    panel.classList.add('cg-panel--visible');
    analyzeAndRender();
  }

  function closePanel() {
    state.isOpen = false;
    const panel = document.getElementById(PANEL_ID);
    if (panel) panel.classList.remove('cg-panel--visible');
  }

  function createPanelElement() {
    const panel = document.createElement('div');
    panel.id = PANEL_ID;
    panel.className = 'cg-panel';
    panel.innerHTML = getPanelHTML();
    bindPanelEvents(panel);
    return panel;
  }

  function getPanelHTML() {
    return `
      <div class="cg-panel__header" id="cg-drag-handle">
        <div class="cg-panel__logo">
          <div class="cg-logo-icon">
            <svg viewBox="0 0 24 24" fill="none"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15l-4-4 1.41-1.41L11 14.17l7.59-7.59L20 8l-9 9z" fill="currentColor"/></svg>
          </div>
          <div>
            <div class="cg-panel__title">ContentGuard</div>
            <div class="cg-panel__subtitle" id="cg-platform-label">Detecting platform...</div>
          </div>
        </div>
        <div class="cg-panel__actions">
          <button class="cg-btn-icon" id="cg-refresh-btn" title="Re-analyze">
            <svg viewBox="0 0 24 24" fill="none"><path d="M17.65 6.35A7.958 7.958 0 0012 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08A5.99 5.99 0 0112 18c-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z" fill="currentColor"/></svg>
          </button>
          <button class="cg-btn-icon" id="cg-close-btn" title="Close">
            <svg viewBox="0 0 24 24" fill="none"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z" fill="currentColor"/></svg>
          </button>
        </div>
      </div>

      <div class="cg-panel__body">
        <!-- Loading state -->
        <div class="cg-loading" id="cg-loading">
          <div class="cg-spinner"></div>
          <div class="cg-loading__text">Analyzing comments...</div>
        </div>

        <!-- Error state -->
        <div class="cg-error" id="cg-error" style="display:none">
          <div class="cg-error__icon">⚠️</div>
          <div class="cg-error__msg" id="cg-error-msg">Backend offline</div>
          <div class="cg-error__hint">Start the backend: <code>uvicorn api.main:app --reload</code></div>
        </div>

        <!-- Content -->
        <div class="cg-content" id="cg-content" style="display:none">
          <!-- Tabs -->
          <div class="cg-tabs">
            <button class="cg-tab active" data-tab="stats">📊 Stats</button>
            <button class="cg-tab" data-tab="comments">💬 Comments</button>
            <button class="cg-tab" data-tab="block">🚫 Block List</button>
          </div>

          <!-- Stats Tab -->
          <div class="cg-tab-content active" id="tab-stats">
            <div class="cg-stat-grid" id="cg-stat-grid"></div>
            <div class="cg-category-chart" id="cg-category-chart"></div>
          </div>

          <!-- Comments Tab -->
          <div class="cg-tab-content" id="tab-comments">
            <div class="cg-comment-filter">
              <button class="cg-filter-btn active" data-filter="all">All</button>
              <button class="cg-filter-btn" data-filter="toxic">🔴 Toxic</button>
              <button class="cg-filter-btn" data-filter="safe">🟢 Safe</button>
            </div>
            <div class="cg-comment-list" id="cg-comment-list"></div>
          </div>

          <!-- Block Recommendations Tab -->
          <div class="cg-tab-content" id="tab-block">
            <div class="cg-block-header">Accounts with highest toxicity rate</div>
            <div class="cg-block-list" id="cg-block-list"></div>
          </div>
        </div>
      </div>

      <!-- Lang selector (bottom bar) -->
      <div class="cg-panel__footer">
        <label class="cg-lang-label">Translate to:</label>
        <select class="cg-lang-select" id="cg-lang-select">
          ${SUPPORTED_LANGS.map(l => `<option value="${l.code}">${l.name}</option>`).join('')}
        </select>
        <div class="cg-backend-status" id="cg-backend-status">
          <span class="cg-dot offline" id="cg-backend-dot"></span>
          <span id="cg-backend-text">Checking...</span>
        </div>
      </div>
    `;
  }

  function bindPanelEvents(panel) {
    // Close button
    panel.querySelector('#cg-close-btn').addEventListener('click', closePanel);

    // Refresh button
    panel.querySelector('#cg-refresh-btn').addEventListener('click', () => {
      state.results = null;
      analyzeAndRender();
    });

    // Tabs
    panel.querySelectorAll('.cg-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        state.activeTab = tab.dataset.tab;
        panel.querySelectorAll('.cg-tab').forEach(t => t.classList.remove('active'));
        panel.querySelectorAll('.cg-tab-content').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        panel.querySelector(`#tab-${state.activeTab}`).classList.add('active');
      });
    });

    // Filter buttons (comments tab)
    panel.querySelectorAll('.cg-filter-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        panel.querySelectorAll('.cg-filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        filterComments(btn.dataset.filter);
      });
    });

    // Language selector
    panel.querySelector('#cg-lang-select').addEventListener('change', (e) => {
      state.selectedLang = e.target.value;
    });
  }

  // ── Analyze & Render ────────────────────────────────────────────────────────
  async function analyzeAndRender() {
    const panel = document.getElementById(PANEL_ID);
    if (!panel) return;

    // Update platform label
    panel.querySelector('#cg-platform-label').textContent =
      `Analyzing ${state.platform.name}`;

    // Show loading
    showPanelState(panel, 'loading');

    // Check backend
    const backendStatus = await sendMessage({ type: 'CHECK_BACKEND' });
    state.backendOnline = backendStatus?.online || false;
    updateBackendIndicator(panel, backendStatus);

    if (!state.backendOnline) {
      showPanelState(panel, 'error', 'Backend is offline');
      return;
    }

    // Scrape comments
    const comments = state.platform.scrapeComments();

    if (!comments || comments.length === 0) {
      showPanelState(panel, 'error', 'No comments found on this page. Try scrolling down first.');
      return;
    }

    // Analyze
    const result = await sendMessage({
      type: 'ANALYZE_COMMENTS',
      comments,
      tabId: null
    });

    if (result?.error) {
      showPanelState(panel, 'error', result.error);
      return;
    }

    state.results = result;
    showPanelState(panel, 'content');
    renderStats(panel, result);
    renderComments(panel, result.comments);
    renderBlockRecommendations(panel, result.blockRecommendations);

    // Update platform label
    panel.querySelector('#cg-platform-label').textContent =
      `${state.platform.name} · ${result.stats.total} comments`;
  }

  function showPanelState(panel, state, errorMsg) {
    panel.querySelector('#cg-loading').style.display = state === 'loading' ? 'flex' : 'none';
    panel.querySelector('#cg-error').style.display = state === 'error' ? 'flex' : 'none';
    panel.querySelector('#cg-content').style.display = state === 'content' ? 'block' : 'none';
    if (state === 'error' && errorMsg) {
      panel.querySelector('#cg-error-msg').textContent = errorMsg;
    }
  }

  function updateBackendIndicator(panel, status) {
    const dot = panel.querySelector('#cg-backend-dot');
    const text = panel.querySelector('#cg-backend-text');
    if (status?.online) {
      dot.className = 'cg-dot online';
      text.textContent = status.modelLoaded ? 'AI Ready' : 'Model loading...';
    } else {
      dot.className = 'cg-dot offline';
      text.textContent = 'Backend offline';
    }
  }

  // ── Render: Stats ───────────────────────────────────────────────────────────
  function renderStats(panel, result) {
    const { stats } = result;
    const grid = panel.querySelector('#cg-stat-grid');

    grid.innerHTML = `
      <div class="cg-stat-card cg-stat-total">
        <div class="cg-stat-value">${stats.total}</div>
        <div class="cg-stat-label">Comments</div>
      </div>
      <div class="cg-stat-card cg-stat-toxic">
        <div class="cg-stat-value">${stats.toxicPercent}%</div>
        <div class="cg-stat-label">Toxic</div>
      </div>
      <div class="cg-stat-card cg-stat-safe">
        <div class="cg-stat-value">${stats.safePercent}%</div>
        <div class="cg-stat-label">Safe</div>
      </div>
      <div class="cg-stat-card cg-stat-block">
        <div class="cg-stat-value">${result.blockRecommendations?.length || 0}</div>
        <div class="cg-stat-label">Block Recs</div>
      </div>
    `;

    // Category chart
    const chart = panel.querySelector('#cg-category-chart');
    const catLabels = {
      toxic: 'Toxic', severe_toxic: 'Severe', obscene: 'Obscene',
      threat: 'Threat', insult: 'Insult', identity_hate: 'Hate'
    };

    const cats = stats.categories || {};
    const maxVal = Math.max(1, ...Object.values(cats));
    const total = stats.total || 1;

    chart.innerHTML = `
      <div class="cg-chart-title">Category Breakdown</div>
      ${Object.entries(catLabels).map(([key, label]) => {
        const count = cats[key] || 0;
        const pct = Math.round((count / total) * 100);
        const barPct = Math.round((count / maxVal) * 100);
        return `
          <div class="cg-chart-row">
            <div class="cg-chart-label">${label}</div>
            <div class="cg-chart-bar-wrap">
              <div class="cg-chart-bar" style="width:${barPct}%" data-cat="${key}"></div>
            </div>
            <div class="cg-chart-count">${count} <span class="cg-chart-pct">(${pct}%)</span></div>
          </div>
        `;
      }).join('')}
    `;
  }

  // ── Render: Comments ────────────────────────────────────────────────────────
  function renderComments(panel, comments) {
    const list = panel.querySelector('#cg-comment-list');
    if (!comments || comments.length === 0) {
      list.innerHTML = '<div class="cg-empty">No comments found.</div>';
      return;
    }

    list.innerHTML = comments.map(c => buildCommentHTML(c)).join('');

    // Bind translate buttons
    list.querySelectorAll('.cg-translate-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const commentId = btn.dataset.id;
        const text = btn.dataset.text;
        await translateCommentInPanel(panel, commentId, text);
      });
    });
  }

  function buildCommentHTML(c) {
    const severityClass = getSeverityClass(c.severity);
    const action = c.action || 'ALLOW';
    const actionEmoji = { ALLOW: '🟢', WARNING: '🟡', HIDE: '🟠', BLOCK: '🔴' }[action] || '⚪';
    const truncated = c.text.length > 140 ? c.text.slice(0, 140) + '…' : c.text;
    const safeText = escapeHTML(truncated);
    const safeAuthor = escapeHTML(c.author || 'Anonymous');
    const scores = c.predictions ? Object.entries(c.predictions)
      .filter(([, v]) => v > 0.3)
      .map(([k, v]) => `<span class="cg-score-chip">${k}: ${Math.round(v * 100)}%</span>`)
      .join('') : '';

    return `
      <div class="cg-comment ${severityClass}" data-id="${escapeHTML(c.id)}" data-toxic="${c.is_toxic}">
        <div class="cg-comment__header">
          <div class="cg-comment__author">
            <div class="cg-avatar">${safeAuthor.charAt(0).toUpperCase()}</div>
            <span class="cg-comment__name">${safeAuthor}</span>
          </div>
          <div class="cg-comment__badge">
            <span class="cg-action-badge cg-action-${action.toLowerCase()}">${actionEmoji} ${action}</span>
          </div>
        </div>
        <div class="cg-comment__text">${safeText}</div>
        ${scores ? `<div class="cg-comment__scores">${scores}</div>` : ''}
        <div class="cg-comment__footer">
          <button class="cg-translate-btn" data-id="${escapeHTML(c.id)}" data-text="${escapeAttr(c.text)}">
            🌐 Translate
          </button>
          <div class="cg-translate-result" id="tr-${escapeHTML(c.id)}" style="display:none"></div>
        </div>
      </div>
    `;
  }

  async function translateCommentInPanel(panel, commentId, text) {
    const resultDiv = panel.querySelector(`#tr-${commentId}`);
    const btn = panel.querySelector(`.cg-translate-btn[data-id="${commentId}"]`);
    if (!resultDiv || !btn) return;

    btn.textContent = '⏳ Translating...';
    btn.disabled = true;
    resultDiv.style.display = 'none';

    const res = await sendMessage({
      type: 'TRANSLATE_COMMENT',
      text,
      targetLang: state.selectedLang
    });

    btn.disabled = false;
    btn.textContent = '🌐 Translate';

    if (res?.ok && res.translated) {
      const langName = SUPPORTED_LANGS.find(l => l.code === state.selectedLang)?.name || state.selectedLang;
      resultDiv.style.display = 'block';
      resultDiv.innerHTML = `
        <div class="cg-translation">
          <span class="cg-translation__lang">${langName}:</span>
          ${escapeHTML(res.translated)}
        </div>
      `;
    } else {
      resultDiv.style.display = 'block';
      resultDiv.innerHTML = `<div class="cg-translation cg-translation--error">Translation failed: ${escapeHTML(res?.error || 'unknown')}</div>`;
    }
  }

  function filterComments(filter) {
    const panel = document.getElementById(PANEL_ID);
    if (!panel) return;
    panel.querySelectorAll('.cg-comment').forEach(el => {
      const isToxic = el.dataset.toxic === 'true';
      if (filter === 'all') el.style.display = '';
      else if (filter === 'toxic') el.style.display = isToxic ? '' : 'none';
      else if (filter === 'safe') el.style.display = !isToxic ? '' : 'none';
    });
  }

  // ── Render: Block Recommendations ──────────────────────────────────────────
  function renderBlockRecommendations(panel, recs) {
    const list = panel.querySelector('#cg-block-list');
    if (!recs || recs.length === 0) {
      list.innerHTML = '<div class="cg-empty">No toxic accounts detected 🎉</div>';
      return;
    }

    list.innerHTML = recs.map(r => `
      <div class="cg-block-card">
        <div class="cg-block-card__avatar">${(r.author || '?').charAt(0).toUpperCase()}</div>
        <div class="cg-block-card__info">
          <div class="cg-block-card__name">${escapeHTML(r.author)}</div>
          <div class="cg-block-card__stats">
            ${r.toxicCount} toxic of ${r.totalComments} comments
            · <strong>${r.toxicRate}%</strong> toxic rate
          </div>
          <div class="cg-block-card__severity">
            Worst: <span class="cg-sev cg-sev-${(r.maxSeverity || 'NONE').toLowerCase()}">${r.maxSeverity}</span>
            · Action: <span class="cg-action-${(r.worstAction || 'ALLOW').toLowerCase()}">${r.worstAction}</span>
          </div>
        </div>
        <div class="cg-block-card__meter">
          <div class="cg-meter-bar" style="height:${r.toxicRate}%"></div>
        </div>
      </div>
    `).join('');
  }

  // ── Draggable Panel ──────────────────────────────────────────────────────────
  function makeDraggable(panel) {
    const handle = panel.querySelector('#cg-drag-handle');
    let startX, startY, startLeft, startTop, dragging = false;

    handle.addEventListener('mousedown', (e) => {
      dragging = true;
      startX = e.clientX;
      startY = e.clientY;
      const rect = panel.getBoundingClientRect();
      startLeft = rect.left;
      startTop = rect.top;
      panel.style.transition = 'none';
      e.preventDefault();
    });

    document.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      panel.style.right = 'auto';
      panel.style.bottom = 'auto';
      panel.style.left = Math.max(0, startLeft + dx) + 'px';
      panel.style.top = Math.max(0, startTop + dy) + 'px';
    });

    document.addEventListener('mouseup', () => {
      dragging = false;
      panel.style.transition = '';
    });
  }

  // ── Platform Comment Scrapers ────────────────────────────────────────────────

  function scrapeTwitter() {
    const results = [];
    document.querySelectorAll('[data-testid="tweet"]').forEach((tweet, i) => {
      const textEl = tweet.querySelector('[data-testid="tweetText"]');
      const authorEl = tweet.querySelector('[data-testid="User-Name"] span');
      if (textEl) {
        results.push({
          id: `tw-${i}`,
          text: textEl.innerText.trim(),
          author: authorEl?.innerText?.trim() || 'Unknown',
          avatar: null
        });
      }
    });
    return results;
  }

  function scrapeReddit() {
    const results = [];
    // New Reddit
    document.querySelectorAll('[data-testid="comment"]').forEach((c, i) => {
      const textEl = c.querySelector('p');
      const authorEl = c.querySelector('[data-testid="comment_author_link"]') ||
                       c.querySelector('a[href*="/user/"]');
      if (textEl) {
        results.push({
          id: `rd-${i}`,
          text: textEl.innerText.trim(),
          author: authorEl?.innerText?.trim() || 'Unknown',
          avatar: null
        });
      }
    });
    // Old Reddit fallback
    if (results.length === 0) {
      document.querySelectorAll('.usertext-body .md p').forEach((p, i) => {
        const entry = p.closest('.entry');
        const authorEl = entry?.querySelector('.author');
        if (p.innerText.trim().length > 2) {
          results.push({
            id: `rd-old-${i}`,
            text: p.innerText.trim(),
            author: authorEl?.innerText?.trim() || 'Unknown',
            avatar: null
          });
        }
      });
    }
    return results;
  }

  function scrapeInstagram() {
    const results = [];
    // Instagram comments (class names change frequently)
    const selectors = ['._a9zs', '._a9ym', 'span[class*="comment"]', 'li span'];
    for (const sel of selectors) {
      document.querySelectorAll(sel).forEach((el, i) => {
        const text = el.innerText.trim();
        if (text.length > 2 && text.length < 2000) {
          const authorEl = el.closest('li')?.querySelector('a');
          results.push({
            id: `ig-${i}`,
            text,
            author: authorEl?.innerText?.trim() || 'Unknown',
            avatar: null
          });
        }
      });
      if (results.length > 0) break;
    }
    return results;
  }

  function scrapeYouTube() {
    const results = [];
    document.querySelectorAll('ytd-comment-renderer').forEach((el, i) => {
      const textEl = el.querySelector('#content-text');
      const authorEl = el.querySelector('#author-text');
      if (textEl) {
        results.push({
          id: `yt-${i}`,
          text: textEl.innerText.trim(),
          author: authorEl?.innerText?.trim() || 'Unknown',
          avatar: null
        });
      }
    });
    return results;
  }

  function scrapeHackerNews() {
    const results = [];
    document.querySelectorAll('.comment').forEach((el, i) => {
      const textEl = el.querySelector('.commtext');
      const authorEl = el.closest('.comtr')?.querySelector('.hnuser');
      if (textEl) {
        results.push({
          id: `hn-${i}`,
          text: textEl.innerText.trim(),
          author: authorEl?.innerText?.trim() || 'Unknown',
          avatar: null
        });
      }
    });
    return results;
  }

  function scrapeGeneric() {
    const results = [];
    const selectors = [
      '[class*="comment"]:not([class*="commentcount"]):not([class*="commentbox"])',
      'article p',
      '[role="article"] p'
    ];
    for (const sel of selectors) {
      document.querySelectorAll(sel).forEach((el, i) => {
        const text = el.innerText?.trim();
        if (text && text.length > 10 && text.length < 2000) {
          results.push({ id: `gen-${i}`, text, author: 'Unknown', avatar: null });
        }
      });
    }
    return results.slice(0, 100);
  }

  // ── Helpers ─────────────────────────────────────────────────────────────────
  function getSeverityClass(severity) {
    const map = { NONE: 'cg-safe', LOW: 'cg-low', MEDIUM: 'cg-medium', HIGH: 'cg-high', CRITICAL: 'cg-critical' };
    return map[severity] || 'cg-safe';
  }

  function escapeHTML(str) {
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function escapeAttr(str) {
    return String(str).replace(/"/g, '&quot;').replace(/'/g, '&#39;').slice(0, 300);
  }

  function sendMessage(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (response) => {
          if (chrome.runtime.lastError) {
            console.warn('[ContentGuard]', chrome.runtime.lastError.message);
            resolve(null);
          } else {
            resolve(response);
          }
        });
      } catch (e) {
        resolve(null);
      }
    });
  }

  // ── Start ───────────────────────────────────────────────────────────────────
  init();

})();
